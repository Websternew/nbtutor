export interface HasUniqueIdentifier {
  id: string;
  uuid?: string;
}
