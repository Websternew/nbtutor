export interface HasSequence {
  sequence: number;
}
