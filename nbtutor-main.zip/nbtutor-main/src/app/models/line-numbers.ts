export interface LineNumbers {
    currentLineNnumbers: number[];
    previousLineNumbers: number[];
    nextLineNumber: number;
}
