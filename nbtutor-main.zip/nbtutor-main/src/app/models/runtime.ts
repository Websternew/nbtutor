import { HasUniqueIdentifier } from './has-unique-identifier';

export interface Hover {
  from: HasUniqueIdentifier;
  to: HasUniqueIdentifier;
}
