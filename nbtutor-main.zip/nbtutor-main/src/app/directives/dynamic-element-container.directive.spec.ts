import { DynamicElementContainerDirective } from './dynamic-element-container.directive';

describe('DynamicElementContainerDirective', () => {
  it('should create an instance', () => {
    const directive = new DynamicElementContainerDirective(null);
    expect(directive).toBeTruthy();
  });
});
