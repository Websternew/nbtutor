export const SelectCell = 'select.Cell';
export const CreateCell = 'create.Cell';
export const DeleteCell = 'delete.Cell';
