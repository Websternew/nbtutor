export const KernelReady = 'kernel_ready.Kernel';
export const KernelRestarting = 'kernel_restarting.Kernel';
export const NotebookSaved = 'notebook_saved.Notebook';
export const SelectCellTypeChanged = 'selected_cell_type_changed.Notebook';
