export enum LogLevel {
  Trace,
  Debug,
  Info,
  Warning,
  Error
}
