export enum VisualizationMethod {
  Modal,
  Embedded,
}
