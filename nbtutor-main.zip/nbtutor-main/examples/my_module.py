def add(a, b):
    ans = a + b
    return ans